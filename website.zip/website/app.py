from flask import Flask, render_template, request
import pandas as pd
import nvdlib

app = Flask(__name__)

# Function to search CVE
def search_cve(cveid):
    api_key = '1aac5d44-2d62-415e-92a8-ff2a6e251fc0'
    cve_id = cveid
    cve_details = nvdlib.searchCVE(cveId=cve_id, key=api_key)
    cve_details = cve_details[0]
    cve = cve_details

    data = {
        'id': [cve.id],
        'description': cve.descriptions[0].value,
        'sourceIdentifier': [cve.sourceIdentifier],
        'published': [cve.published],
        'lastModified': [cve.lastModified],
        'vulnStatus': [cve.vulnStatus],
        'cisaExploitAdd': [getattr(cve, 'cisaExploitAdd', None)],
        'cisaActionDue': [getattr(cve, 'cisaActionDue', None)],
        'cisaRequiredAction': [getattr(cve, 'cisaRequiredAction', None)],
        'cisaVulnerabilityName': [getattr(cve, 'cisaVulnerabilityName', None)],
        'v31score': [getattr(cve, 'v31score', None)],
        'v31vector': [getattr(cve, 'v31vector', None)],
        'v31severity': [getattr(cve, 'v31severity', None)],
        'v31attackVector': [getattr(cve, 'v31attackVector', None)],
        'v31attackComplexity': [getattr(cve, 'v31attackComplexity', None)],
        'v31privilegesRequired': [getattr(cve, 'v31privilegesRequired', None)],
        'v31userInteraction': [getattr(cve, 'v31userInteraction', None)],
        'v31scope': [getattr(cve, 'v31scope', None)],
        'v31confidentialityImpact': [getattr(cve, 'v31confidentialityImpact', None)],
        'v31integrityImpact': [getattr(cve, 'v31integrityImpact', None)],
        'v31availabilityImpact': [getattr(cve, 'v31availabilityImpact', None)],
        'v31exploitability': [getattr(cve, 'v31exploitability', None)],
        'v31impactScore': [getattr(cve, 'v31impactScore', None)],
        'v2score': [getattr(cve, 'v2score', None)],
        'v2vector': [getattr(cve, 'v2vector', None)],
        'v2severity': [getattr(cve, 'v2severity', None)],
        'v2accessVector': [getattr(cve, 'v2accessVector', None)],
        'v2accessComplexity': [getattr(cve, 'v2accessComplexity', None)],
        'v2authentication': [getattr(cve, 'v2authentication', None)],
        'v2confidentialityImpact': [getattr(cve, 'v2confidentialityImpact', None)],
        'v2integrityImpact': [getattr(cve, 'v2integrityImpact', None)],
        'v2availabilityImpact': [getattr(cve, 'v2availabilityImpact', None)],
        'v2exploitability': [getattr(cve, 'v2exploitability', None)],
        'v2impactScore': [getattr(cve, 'v2impactScore', None)],
        'score': [cve.score]
    }

    df = pd.DataFrame(data, index=[0])
    return df

# Route for the homepage
@app.route('/')
def index():
    return render_template('index.html')

# Route for handling form submission
@app.route('/search_cve', methods=['POST'])
def search():
    cve_id = request.form['cve_id']
    df = search_cve(cve_id)
    html_table = df.to_html(classes='data', index=False)
    # return render_template('result.html', tables=[df.to_html(classes='data')], titles=df.columns.values)
    return render_template('result.html', tables=data_for_template, titles=df.columns.values)

if __name__ == '__main__':
    app.run(debug=True)