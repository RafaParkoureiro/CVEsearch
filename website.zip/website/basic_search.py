import nvdlib
import pandas as pd

def search_cve(cveid):
    api_key = '1aac5d44-2d62-415e-92a8-ff2a6e251fc0'
    cve_id = cveid

    cve_details = nvdlib.searchCVE(cveId=cve_id, key=api_key)

    cve_details = cve_details[0]

    data = {
        'id': [cve_details.id],
        'description': cve_details.descriptions[0].value,
        'sourceIdentifier': [cve_details.sourceIdentifier],
        'published': [cve_details.published],
        'lastModified': [cve_details.lastModified],
        'vulnStatus': [cve_details.vulnStatus],
        'cisaExploitAdd': [cve_details.cisaExploitAdd],
        'cisaActionDue': [cve_details.cisaActionDue],
        'cisaRequiredAction': [cve_details.cisaRequiredAction],
        'cisaVulnerabilityName': [cve_details.cisaVulnerabilityName],
        'v31score': [cve_details.v31score],
        'v31vector': [cve_details.v31vector],
        'v31severity': [cve_details.v31severity],
        'v31attackVector': [cve_details.v31attackVector],
        'v31attackComplexity': [cve_details.v31attackComplexity],
        'v31privilegesRequired': [cve_details.v31privilegesRequired],
        'v31userInteraction': [cve_details.v31userInteraction],
        'v31scope': [cve_details.v31scope],
        'v31confidentialityImpact': [cve_details.v31confidentialityImpact],
        'v31integrityImpact': [cve_details.v31integrityImpact],
        'v31availabilityImpact': [cve_details.v31availabilityImpact],
        'v31exploitability': [cve_details.v31exploitability],
        'v31impactScore': [cve_details.v31impactScore],
        'v2score': [cve_details.v2score],
        'v2vector': [cve_details.v2vector],
        'v2severity': [cve_details.v2severity],
        'v2accessVector': [cve_details.v2accessVector],
        'v2accessComplexity': [cve_details.v2accessComplexity],
        'v2authentication': [cve_details.v2authentication],
        'v2confidentialityImpact': [cve_details.v2confidentialityImpact],
        'v2integrityImpact': [cve_details.v2integrityImpact],
        'v2availabilityImpact': [cve_details.v2availabilityImpact],
        'v2exploitability': [cve_details.v2exploitability],
        'v2impactScore': [cve_details.v2impactScore],
        'score': [cve_details.score]  # Wrap single values in a list to match the length of the index
    }

    # Creating DataFrame
    df = pd.DataFrame(data, index=[0])

    return df